import { BAND_META, arClock, arNum, bandOf, depthAt, freqAt, persistenceAt } from '@/lib/model'

type Props = {
  elapsedSec: number
  running: boolean
  total: number
  onStart: () => void
  onPause: () => void
  onReset: () => void
}

export default function StatePanel({ elapsedSec, running, total, onStart, onPause, onReset }: Props) {
  const tMin = elapsedSec / 60
  const f = freqAt(tMin)
  const band = bandOf(f)
  const meta = BAND_META[band]
  const depth = depthAt(tMin)
  const persistence = persistenceAt(tMin)

  return (
    <section className="flex h-full flex-col gap-8">
      {/* الحالة اللحظية */}
      <div className="flex flex-col gap-3">
        <span className="text-xs tracking-[0.3em] text-[--ink-faint]">الحالة المقدَّرة الآن</span>
        <div className="flex items-end gap-4">
          <span
            className="font-display text-5xl leading-none sm:text-7xl transition-colors duration-700"
            style={{ color: meta.color }}
          >
            {meta.ar}
          </span>
          <div className="mb-2 flex flex-col">
            <span className="tabular-nums text-2xl font-semibold text-[#f2ede2]">
              {arNum(f, 1)} <span className="text-sm font-normal text-[--ink-dim]">هرتز</span>
            </span>
            <span className="text-xs text-[--ink-dim]">{meta.range}</span>
          </div>
        </div>
        <p className="text-sm leading-relaxed text-[--ink-dim]">{meta.desc}</p>

        {/* مقياس العمق */}
        <div className="mt-2 flex flex-col gap-2">
          <div className="flex justify-between text-[11px] text-[--ink-faint]">
            <span>بداية التسبيح</span>
            <span>استغراق عميق</span>
          </div>
          <div className="relative h-1.5 overflow-hidden rounded-full bg-[#fce1b6]/8">
            <div
              className="absolute inset-y-0 right-0 rounded-full transition-all duration-700"
              style={{
                width: `${Math.max(depth * 100, 1.5)}%`,
                background: `linear-gradient(to left, #d98a6a, #d4b67e, #5ba8a0)`,
                backgroundSize: '300% 100%',
                backgroundPosition: `${(1 - depth) * 100}% 0`,
              }}
            />
          </div>
        </div>
      </div>

      <div className="hairline-b" />

      {/* إحصاءات الجلسة */}
      <div className="grid grid-cols-3 gap-4">
        <div className="flex flex-col gap-1">
          <span className="text-[11px] text-[--ink-faint]">مدة المكوث</span>
          <span className="tabular-nums text-xl font-semibold text-[#f2ede2]">{arClock(elapsedSec)}</span>
        </div>
        <div className="flex flex-col gap-1">
          <span className="text-[11px] text-[--ink-faint]">مجموع التسبيحات</span>
          <span className="tabular-nums text-xl font-semibold text-[#f2ede2]">{arNum(total)}</span>
        </div>
        <div className="flex flex-col gap-1">
          <span className="text-[11px] text-[--ink-faint]">لو توقفت الآن يمتد الأثر</span>
          <span className="tabular-nums text-xl font-semibold" style={{ color: meta.color }}>
            ≈ {arNum(persistence)} <span className="text-xs font-normal">دقيقة</span>
          </span>
        </div>
      </div>

      {/* أزرار الجلسة */}
      <div className="mt-auto flex items-center gap-3">
        {running ? (
          <button
            onClick={onPause}
            className="rounded-full border border-[#d4b67e]/50 px-6 py-2 text-sm text-[#fce1b6] transition-colors hover:bg-[#d4b67e]/10"
          >
            إيقاف مؤقت
          </button>
        ) : (
          <button
            onClick={onStart}
            className="rounded-full bg-[#d4b67e] px-6 py-2 text-sm font-semibold text-[#0c1723] transition-colors hover:bg-[#fce1b6]"
          >
            {elapsedSec > 0 ? 'استئناف المكوث' : 'ابدأ المكوث'}
          </button>
        )}
        <button
          onClick={onReset}
          className="rounded-full px-5 py-2 text-sm text-[--ink-dim] transition-colors hover:text-[#fce1b6]"
        >
          تصفير
        </button>
        <span className={`mr-auto flex items-center gap-2 text-[11px] text-[--ink-faint] ${running ? 'breathe' : ''}`}>
          <span
            className="inline-block h-1.5 w-1.5 rounded-full"
            style={{ background: running ? meta.color : 'rgba(242,237,226,0.25)' }}
          />
          {running ? 'مكوث جارٍ' : 'متوقف'}
        </span>
      </div>
    </section>
  )
}
